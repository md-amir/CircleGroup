package com.half.util;

public class AppConstant {
	
	public static String INVITATION_VALUE = "invitations";
	public static String SCHEDULE_VALUE = "Schedule";
	public static String ALERT_VALUE = "Alert";
	public static String LOS_GREEN_VALUE = "green";
	public static String LOS_RED_VALUE = "red";
	public static String LOS_ORANGE_VALUE = "orange";
	public static String LOS_YELLOW_VALUE = "yellow";

	public static String ORGANIZATION_CORA_VALUE = "cora";
	public static String ORGANIZATION_HR_VALUE = "hr";
	public static String ORGANIZATION_FINANCE_VALUE = "finance";
	public static String ORGANIZATION_SECURITY_VALUE = "security";
	public static String ORGANIZATION_IT_VALUE = "it";
	public static String ORGANIZATION_LEGAL_VALUE = "legal";
}
