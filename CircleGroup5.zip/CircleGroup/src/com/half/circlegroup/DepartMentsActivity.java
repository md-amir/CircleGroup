package com.half.circlegroup;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class DepartMentsActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_depart_ments);
	}

	

}
