package com.half.util;

/**
 * @author Tushar
 */
public interface ServerResponseListener
{
	public void serverResponse(Response response);
}
