package com.half.util;

public class Keys {
	
	
	public static String LOS_TEAM_GREEN_KEY = "losTeamGreen";
	public static String LOS_TEAM_RED_KEY = "losTeamRed";
	public static String LOS_TEAM_YELLOW_KEY = "losTeamYellow";
	public static String LOS_TEAM_ORANGE_KEY = "losTeamOrange";

	public static String ORGANIZATION_CORA_KEY = "organizationCora";
	public static String ORGANIZATION_HR_KEY = "organizationHr";
	public static String ORGANIZATION_FINANCE_KEY = "organizationFinance";
	public static String ORGANIZATION_IT_KEY = "organizationIt";
	public static String ORGANIZATION_SECURITY_KEY = "organizationSecurity";
	public static String ORGANIZATION_LEGAL_KEY = "organizationLegal";
	
	public static String ALERT_SCHEDULE_KEY = "losTeamGreen";
	
	
}
