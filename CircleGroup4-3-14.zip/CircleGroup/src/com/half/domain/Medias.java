package com.half.domain;

public class Medias {

}
