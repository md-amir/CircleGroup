package com.half.domain;

public class Department {
	private String departmentName;
	private String departmentNumber;
	private int membersAmount;


}
