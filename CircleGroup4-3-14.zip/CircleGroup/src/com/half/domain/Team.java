package com.half.domain;

public class Team {
	private String teamName;
	private String teamNumber;
	private int membersAmount;

}
