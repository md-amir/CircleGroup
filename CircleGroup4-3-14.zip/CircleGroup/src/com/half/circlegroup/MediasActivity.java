package com.half.circlegroup;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class MediasActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_medias);
	}

	

}
